package com.example.hipotenusa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Math.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCalcular.setOnClickListener{calcularClick()}
        btnLimpiar.setOnClickListener{limpiarClick()}
    }

    private fun calcularClick(){
        if(txtLadoA.text.isEmpty() || txtLadoB.text.isEmpty()){

        } else {

        }
    }

    private fun limpiarClick() {
        txtResultado.text = ""
        txtLadoA.text = null
        txtLadoB.text = null
    }
}